import React ,{useState} from 'react';
import './style.css';
import {Link,useHistory} from "react-router-dom";
import api from '../../services/api'
import { FiLogIn} from 'react-icons/fi';
import help from '../../assets/help.png'
import logo from '../../assets/logo.svg'
export default function  Logon(){
    const [id,setId]=useState("");
    const history=useHistory()
   async function Verify(e){
      e.preventDefault()
     try{ 
     const response= await api.post('/session',{id});
     
     alert(`login feito com sucesso ${response.data.nome}`);
     localStorage.setItem('ongid',id);
     localStorage.setItem('ongName',response.data.nome);
     history.push('/profiler');
     
     }catch(err){
         alert("erro de id")
     }
     }
    return(
  <div className="Logon-conteiner">
      <section className="form">
      <img  src={logo} alt="logo" />
      <form  onSubmit={Verify}>
          <h1>Faça seu logon </h1>
          <input  placeholder="Sua ID"
          value={id}
          onChange={e=>setId(e.target.value)}/>

          <button type="submit" className="button">Entrar</button>
          
          <Link  className='back-link'to="/registre" >
          <FiLogIn size={16} color="green"/>
              Nao tenho cadastro
          </Link>
      </form>
      
      </section>
      <img src={help} alt="help"/>
  </div>
    );
}