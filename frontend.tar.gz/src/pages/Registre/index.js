import React,{useState} from 'react';
import './styles.css'
import api from '../../services/api';
import {Link,useHistory}from 'react-router-dom';
import logo from '../../assets/logo.svg'
import {FiArrowLeft} from 'react-icons/fi';
export default function Register(){
  const [nome,setName]=useState("");
  const [email,setEmail]=useState("");
  const [whatsapp,setWhatsApp]=useState("");
  const [city,setCidade]=useState("");
  const [uf,setUf]=useState("");
  const histoy=useHistory();
 async function Headle(e){
    e.preventDefault();
    const date={
      nome,
      email,
      whatsapp,
      city,
      uf,
    };
    try{
    const response= await api.post('/ongs',date);
    alert(`seu Id de acesso ${response.data.id}`);
    histoy.push('/');
    }catch(err){
      alert("error no cadastro")
    }

  }
  
  return(
      <div className="registre-conteiner" >
       <div className='content' >
         <section>
             <img src={logo} alt="help"/>

             <h1>Cadastro</h1>
             <p>Faça seu cadastro, entre na plataforma e ajude pessoas a encontrar os casos da sua ONG</p>
         <Link className="back-link" to='/'>
           <FiArrowLeft  size={18} color='green'/>
           Login
         </Link>
         </section>
         <form  onSubmit={Headle}>
           <input placeholder="Nome da ONG"
           value={nome}
           onChange={e=>setName(e.target.value)}
            />
           <input type='email'placeholder="Email"
            value={email}
            onChange={e=>setEmail(e.target.value)}
            />
           <input placeholder="WhatsApp"
            value={whatsapp}
            onChange={e=>setWhatsApp(e.target.value)}
            />
           <div className="grup-input">
           <input placeholder="Cidade"
            value={city}
            onChange={e=>setCidade(e.target.value)}
            />
           <input placeholder="UF" style={{width:80}}
            value={uf}
            onChange={e=>setUf(e.target.value)}
            />
           </div>
           <button className="button" type='submit'>Cadastrar</button>
         </form>
       </div>
      </div>
  );
}