import React,{useState,useEffect} from 'react';
import {Link,useHistory} from 'react-router-dom';
import {FiPower,FiTrash2} from 'react-icons/fi'
import './style.css'
import api from '../../services/api'
import Logo from '../../assets/logo.svg';
export default function Profile(){
const idong=localStorage.getItem('ongid');
const [Insidents,setInsidents]=useState([]);
const history=useHistory();
useEffect(()=>{
api.get('/profile',{headers:{
    autori:idong,
}
}).then(response=>{
    setInsidents(response.data)
})

},[idong])
async function Delete(id){
    try{
        await api.delete(`/incidents/${id}`,{
            headers:{
                autori:idong,
            }
        })
   setInsidents(Insidents.filter(incidents => incidents.id !== id ));
    }catch(err){
        alert("error")
    }
}
    const ongName=localStorage.getItem('ongName')
 function Logout(){
  localStorage.clear()
  history.push('/')
}
  return (
      <div className="profile-conteiner">
          <header >
         <img src={Logo} alt="logo"/>
         <span>Bem vinda,{ongName}</span>
         <Link to='/Insidents/new' className="button">Cadastrar novo caso </Link>
         <button onClick={Logout} type="button"><FiPower  size={18} color="green"/></button>
          </header>
          <h1>Casos cadastrados</h1>
          <ul>
             {Insidents.map(Insident=>(  
                   <li key={Insident.id}>
                  <strong>Caso:</strong>
                       <p>{Insident.title}</p>

                  <strong>Descricao:</strong>
                  <p>{Insident.description}</p>

                  <strong>Valor:</strong>
                  <p>{Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Insident.value)}</p>

                  <button onClick={()=>Delete(Insident.id)} type="button">
                      <FiTrash2  size={18} color="#a8a8b3"/>
                  </button>
              </li>
              )
              )}
          </ul>
      </div>
  );
}