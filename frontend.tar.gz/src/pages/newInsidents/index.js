import React,{useState} from 'react';
import './styles.css';
import {Link,useHistory} from 'react-router-dom';
import {FiArrowLeft} from 'react-icons/fi';
import logo from "../../assets/logo.svg"
import api from  '../../services/api'

export default function New(){
const [title,setTitle]=useState('');
const [description,setdescription]=useState('');
const [value,setValor]=useState('');
const ongid=localStorage.getItem('ongid');
const history=useHistory();
async function Newinsidents(e){
     e.preventDefault();
     const data={
       title,
       description,
       value,
     };
     try{
        await api.post('/incidents',data,{
          headers:{
          autori: ongid,
        }
        })
       console.log('cheguei')
       history.push('/profiler');
     }catch(err){
     alert("error ");
     }
  }
    return (
        <div className="insidents-conteiner" >
        <div className='content' >
          <section>
              <img src={logo} alt="help"/>
 
              <h1>Cadastrar novo caso </h1>
              <p>descreva o caso  corrretamente para encontrar sua ajuda </p>
          <Link className="back-link" to='/profiler'>
            <FiArrowLeft  size={18} color='green'/>
            Voltar para home 
          </Link>
          </section>
          <form onSubmit={Newinsidents}>
            <input placeholder="Titulo do caso 
            "value={title}
            onChange={e=>setTitle(e.target.value)}/>
            <textarea placeholder="Descricao"
            value={description}
            onChange={e=>setdescription(e.target.value)}/>
            <input placeholder="Valor em reais"
            value={value}
            onChange={e=>setValor(e.target.value)}/>
            <button className="button" type='submit'>Cadastrar</button>
          </form>
        </div>
       </div>

    );
}