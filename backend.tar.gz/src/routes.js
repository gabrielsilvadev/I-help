const express = require("express");
const routes = express.Router();
const {celebrate,Segments,Joi} = require('celebrate');

const oncontrollerOngs=require('./controller/controllerOngs');
const oncontrollerIncidents=require('./controller/controllerIncidents');
const oncontrollersession=require('./controller/sessioncontroller');
const controllerfile=require('./controller/controllerfile');


routes.get('/incidents',celebrate({
    [Segments.QUERY]:Joi.object().keys({
        page:Joi.number(),
    })
}),oncontrollerIncidents.index);
routes.get("/ongs",oncontrollerOngs.index);

routes.post("/ongs",celebrate({
[Segments.BODY]:Joi.object().keys({
    nome:Joi.string().required(),
    email:Joi.string().required().email(),
    whatsapp:Joi.number().required().min(10),
    city: Joi.string().required(),
    uf:Joi.string().required().length(2),

})
}),oncontrollerOngs.create);

routes.post('/incidents',celebrate({
    [Segments.PARAMS]:Joi.object().keys({
        id:Joi.number().required(),
    }),
    [Segments.BODY]:Joi.object().keys({
        title:Joi.string().required(),
        description:Joi.string().required(),
        value:Joi.number().required()
    })
}),
oncontrollerIncidents.create);

routes.delete('/incidents/:id',oncontrollerIncidents.delete);

routes.get("/profile",celebrate({
    [Segments.HEADERS]:Joi.object({
        authorization:Joi.string().required(),
     }).unknown(),
    }),controllerfile.index);

routes.post("/session",celebrate({
    [Segments.PARAMS]:Joi.object().keys({
        id:Joi.number().required(),
    })
}),oncontrollersession.create);

module.exports = routes; 