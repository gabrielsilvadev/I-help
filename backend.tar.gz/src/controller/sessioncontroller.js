const conection = require("../datebase/conection");

module.exports={
    async create(request,response){
        const {id} = request.body;
        const ong = await conection('ongs')
        .where("id",id)
        .select("nome")
        .first();

        if (!ong){
            return response.status(400).json({error: "nao existe ongs com esse id"})
        }
        return response.json(ong);
    }
}