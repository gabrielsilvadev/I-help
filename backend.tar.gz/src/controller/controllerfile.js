const conection = require("../datebase/conection"); // open conect 
module.exports = {
  async index(request , response){ // funcao retorna todos os incidentes 
    const ongs_id =request.headers.autori;
    const incident =await conection('incidents')
    .where("id_ongs",ongs_id)
    .select('*');
    return response.json(incident);
  }
};