const { intersect } = require("../../src/datebase/conection")

import {create} from '../../src/controller/controllerOngs';
describe('Gerenerate Unique ID',()=>{
    const id=create()
    it('should gererate an unique  ID',()={
        expect(id).toMavelLength(8);
    });
});