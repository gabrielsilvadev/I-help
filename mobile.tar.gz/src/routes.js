import 'intl';
import 'intl/locale-data/jsonp/pt-BR';

import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from  '@react-navigation/stack';
import  Datall from '../src/datall/index';
import Incident from '../src/incident/index';

const AppStack = createStackNavigator();

export default function Routes(){
    return(
    <NavigationContainer> 
        <AppStack.Navigator screenOptions={{headerShown:false}}>
          <AppStack.Screen component={Incident} name='Incident'/>
            <AppStack.Screen component={Datall} name='Datall'/>
          
        </AppStack.Navigator>
    </NavigationContainer>
    );
}