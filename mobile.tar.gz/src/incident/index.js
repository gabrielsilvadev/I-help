import  React ,{useEffect,useState}from 'react';
import {View,Image,Text,TouchableOpacity ,FlatList} from 'react-native';
import Logo from '../../assets/icon.png';
import api from '../services/api'; 
import {useNavigation} from '@react-navigation/native'
import styles from'./styles';
import Intl from 'intl/lib/core';
export default function Incident(){
const navigation = useNavigation();

  function  goNext(incident){
   navigation.navigate('Datall',{incident});
  }
  const [incidents,setIncidents]=useState([]);
  console.log(incidents)
  const [total,setTotal]=useState(0);
  const [page,setpage]=useState(1);
  const [loading,setLoading]=useState(false);
  async function loadIncident(){
    if(loading){
      return;
    }
    if(total >0 && incidents.length===total){
      return;
    }

    setLoading(true);
      const response = await api.get('incidents',{params:{page}});
     
      setIncidents([...incidents,...response.data]);
      setTotal(response.headers['x-total-count']);
      setpage(page+1);
      setLoading(false);

    
  }
  useEffect(()=>{
    loadIncident();
  },[])
  return(
    <View style={styles.conteiner}>
    <View style={styles.header}>
    <Image
     style={styles.Image}
     source={Logo}
     resizeMode='contain'/>
    <Text style={styles.headerText}>
      Total de <Text style={styles.headerTextBold}> {total} Casos </Text>
    </Text>
    </View>
     <Text style={styles.title}>Bem vindo!</Text>
    <Text style={styles.subTitle}> Seja o heroi de um desses casos e salve o dia </Text>
   
    
    <FlatList
    style={styles.IncidentList}
    data={incidents}
    keyExtractor={incident=>String(incident.id)}
    onEndReached={loading}
    onEndReachedTheeshold={0.2}
    renderItem={({item:incident})=>(
      <View style={styles.incident} >
        <TouchableOpacity onPress={()=>goNext(incident)}>
      <Text  style={styles.incidentProp}>Ongs:</Text>
      <Text style={styles.incidentVelue}>{incident.nome}</Text>
     
      <Text  style={styles.incidentProp}>Caso:</Text>
    <Text style={styles.incidentVelue}>{incident.title}</Text>
      
      <Text  style={styles.incidentProp}>Valor</Text>
    <Text style={styles.incidentVelue}>
      {Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(incident.value)}
      </Text>
    
     </TouchableOpacity>
    </View>
  )}
    
    
    /> 
   
    </View>
  );
}
