import  React from 'react';
import {View,Image,TouchableOpacity,Text,Linking} from 'react-native';
import {Feather} from '@expo/vector-icons';
import {useNavigation,useRoute} from '@react-navigation/native';
import * as MailComposer from 'expo-mail-composer';
import styles from './styles';
import Logo from '../assets/icon.png';

export default function Detall(){
  const navigation=useNavigation();
  const route = useRoute();
  const incidents=route.params.incident;
 
  const  message= ` Ola ${incidents.nome}  estou entrando em contato pois gostaria de ajudar no caso  ${incidents.title} com o valor ${incidents.value}  `;
  function goBack(){
    navigation.goBack()
  }
  function sendEmail(){
     MailComposer.composeAsync({ 
       subject:`Heroi do caso  ${incidents.title}`,
       recipients:[incidents.email],
       body:message
     })
  }
  function sendWhatsapp(){
    Linking.openURL(`whatsapp://send?phone=${incidents.whatsapp}text=${message}`)
  }
  return(
    <View style={styles.conteiner}>
     <View style={styles.header}>
    <Image
     style={styles.Image}
     source={Logo}
     resizeMode='contain'/>
      <TouchableOpacity  onPress={()=>goBack()}>
        <Feather  name='arrow-left'  size={35} color='green' style={{marginRight:15}}/>
      </TouchableOpacity>
    </View> 
    <View style={styles.incident}>
  
      <Text  style={[styles.incidentProp],{marginTop:0,  fontWeight:'bold',}}>Ongs:</Text>
  <Text style={styles.incidentVelue}>{incidents.nome} de {incidents.city}/{incidents.uf}</Text>
     
      <Text  style={styles.incidentProp}>Caso:</Text>
  <Text style={styles.incidentVelue}>{incidents.title}</Text>
      
      <Text  style={styles.incidentProp}>Valor</Text>
      <Text style={styles.incidentVelue}>{Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(incidents.value)}</Text>

    </View>
    <View style={styles.ContactBox}>
        <Text style={styles.titleBox}> Salve o Dia </Text>
        <Text style={styles.titleBox}> Seja o Heroi   </Text>
        <Text style={styles.textBox}> Entre em Contato </Text>
        <View style={styles.actions}>
          <TouchableOpacity onPress={()=>sendWhatsapp()} style={styles.buttonBox}><Text style={styles.textBoxbutton}>whasapp</Text></TouchableOpacity>
          <TouchableOpacity onPress={()=>sendEmail()} style={styles.buttonBox}><Text  style={styles.textBoxbutton}>email</Text></TouchableOpacity>
        </View>
    </View>
    </View>
 
  );
}
